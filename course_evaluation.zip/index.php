<?php
	/*when the user access the system,by default we need to re-direct into Student Login page*/
	header("Location:./student/");
	exit;
?>