window.onload = function() 
{
	document.getElementsByTagName('input')[0].focus();
};