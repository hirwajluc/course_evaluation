<?php

echo mktime();

?>
